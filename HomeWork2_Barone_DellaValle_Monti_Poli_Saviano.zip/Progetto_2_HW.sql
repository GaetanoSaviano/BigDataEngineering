-- Databricks notebook source
-- MAGIC %md
-- MAGIC # Databricks in 5 minutes

-- COMMAND ----------

-- MAGIC %md ## Run the notebook
-- MAGIC
-- MAGIC Press <img src="http://docs.databricks.com/_static/images/notebooks/nb-run-all.png"/></a> or select **Run all** from the **Run** menu to run the commands in the notebook. You may be prompted to select an existing cluster ([AWS](https://docs.databricks.com/notebooks/notebook-ui.html#attach-a-notebook-to-a-cluster)|[Azure](https://learn.microsoft.com/azure/databricks/notebooks/notebook-ui#attach-a-notebook-to-a-cluster)|[GCP](https://docs.gcp.databricks.com/notebooks/notebook-ui.html#attach-a-notebook-to-a-cluster)) or to create a personal compute resource ([AWS](https://docs.databricks.com/clusters/personal-compute.html)|[Azure](https://learn.microsoft.com/azure/databricks/clusters/personal-compute)). 
-- MAGIC
-- MAGIC As the notebook is running, <img src="http://docs.databricks.com/_static/images/notebooks/nb-run-all.png"/></a> changes to <img src="http://docs.databricks.com/_static/images/notebooks/nb-interrupt-button.png"/></a> and the compute button shows a green dot and the name of the compute resource <img src="http://docs.databricks.com/_static/images/notebooks/compute-indicator.png"/></a>.

-- COMMAND ----------

-- MAGIC %md 
-- MAGIC ## Filtering

-- COMMAND ----------

DROP TABLE IF EXISTS avocado;

CREATE TABLE avocado
USING csv
OPTIONS (path "/FileStore/tables/avocado-1.csv", header "true", delimiter ";", quotechar '"', inferSchema "true");

-- COMMAND ----------

SELECT * from avocado

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ## The next command manipulates the data and displays the results 
-- MAGIC
-- MAGIC Specifically, the command:
-- MAGIC 1. Selects color and price columns, averages the price, and groups and orders by color.
-- MAGIC 1. Displays a table of the results.

-- COMMAND ----------

SELECT *
FROM avocado 
WHERE year = 2015

-- COMMAND ----------

SELECT *
FROM avocado
WHERE `Total Volume` < 500;

-- COMMAND ----------

DESCRIBE avocado;


-- COMMAND ----------

SELECT *
FROM avocado
WHERE `AveragePrice ` > 3;

-- COMMAND ----------

SELECT *
FROM avocado
WHERE type = "conventional" AND `AveragePrice ` < 0.50;

-- COMMAND ----------

SELECT *
FROM avocado
WHERE Date >= '2015-12-27' AND `Total Volume` > 50000;

-- COMMAND ----------

SELECT color, avg(price) AS price FROM diamonds GROUP BY color ORDER BY color

-- COMMAND ----------

SELECT DISTINCT region
FROM avocado;

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ## Summarization
-- MAGIC

-- COMMAND ----------

SELECT COUNT(*)
FROM avocado
WHERE region = 'Boston';

-- COMMAND ----------

SELECT type, round(sum(`Total Volume`),2)
FROM avocado
GROUP BY(type)


-- COMMAND ----------

SELECT COUNT(*)
FROM avocado
WHERE region = 'Boston';

-- COMMAND ----------

SELECT region, ROUND(AVG(`AveragePrice `), 2) AS avg_AveragePrice
FROM avocado
GROUP BY region
ORDER BY avg_AveragePrice DESC;

-- COMMAND ----------

SELECT region, ROUND(AVG(`AveragePrice `), 2) AS avg_AveragePrice
FROM avocado
GROUP BY region
ORDER BY avg_AveragePrice DESC;
SET hive.exec.dynamic.partition.mode=nonstrict;

WITH yearly_avg_price AS (
    SELECT year, region, round(AVG(`AveragePrice `),2) AS AveragePriceMean
    FROM avocado
    WHERE year >= 2015 AND year <= 2018
    GROUP BY year, region
)
SELECT year, region, AveragePriceMean
FROM (
    SELECT *, ROW_NUMBER() OVER (PARTITION BY year ORDER BY AveragePriceMean DESC) AS rn
    FROM yearly_avg_price
) ranked
WHERE rn = 1;

-- COMMAND ----------

SELECT year, type, round(SUM(`Total Volume`),2) AS TotalVolume
FROM avocado
GROUP BY year, type;

-- COMMAND ----------

SELECT year, type, 
       round(SUM(`Small Bags`),2) AS TotalSmallBags,
       round(SUM(`Large Bags`),2) AS TotalLargeBags,
       round(SUM(`XLarge Bags`),2) AS TotalXLargeBags
FROM avocado
GROUP BY year, type;

-- COMMAND ----------

SET hive.exec.dynamic.partition.mode=nonstrict;

CREATE TABLE bag_sum_by_region_type AS
SELECT region, type,
       ROUND(SUM(`Small Bags`), 2) AS TotalSmallBags,
       ROUND(SUM(`Large Bags`), 2) AS TotalLargeBags,
       ROUND(SUM(`XLarge Bags`), 2) AS TotalXLargeBags
FROM avocado
GROUP BY region, type;

-- Mostra il risultato
SELECT *
FROM bag_sum_by_region_type
LIMIT 10;

-- COMMAND ----------

SELECT type, year, region,
       ROUND(SUM(`4046`), 2) AS TotalVolume_4046,
       ROUND(SUM(`4225`), 2) AS TotalVolume_4225,
       ROUND(SUM(`4770`), 2) AS TotalVolume_4770
FROM avocado
GROUP BY type, year, region;
