import streamlit as st
import pandas as pd
from pymongo.mongo_client import MongoClient
from pymongo.server_api import ServerApi
import plotly.express as px
import matplotlib.pyplot as plt
import datetime
import fireworks.client
import dotenv
import chromadb
import json
from tqdm.auto import tqdm
import pandas as pd
import random
from sentence_transformers import SentenceTransformer
from pymongo import MongoClient
import os
import networkx as nx
import folium
from streamlit_folium import folium_static
from geopy.geocoders import Nominatim
from geopy.exc import GeopyError
from streamlit_folium import folium_static
from opencage.geocoder import OpenCageGeocode
from wordcloud import WordCloud
import geocoder
from nltk.sentiment.vader import SentimentIntensityAnalyzer
import nltk
nltk.download('vader_lexicon')
dotenv.load_dotenv()

# MongoDB connection URI
uri = "mongodb+srv://lolli9960:EsameMoscat0@cluster0.xcvsfap.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0"

# Create a new client and connect to the server
client = MongoClient(uri, server_api=ServerApi('1'))

# Access the database and collection
db = client['Medici55']
collection = db['Medici55']

@st.cache_data
def load_doctors():
    pipeline = [
        {
            "$match": {
                "Question Date": {"$type": "string"}
            }
        },
        {
            "$group": {
                "_id": {
                    "Doctor": "$Doctor",
                    "Year": {
                        "$year": {
                            "$dateFromString": {
                                "dateString": "$Question Date",
                                "format": "%Y-%m-%d"
                            }
                        }
                    }
                }
            }
        },
        {
            "$group": {
                "_id": "$_id.Doctor",
                "years": {"$addToSet": "$_id.Year"},
                "yearCount": {"$sum": 1}
            }
        },
        {
            "$match": {
                "yearCount": {"$gt": 1}
            }
        },
        {
            "$project": {
                "_id": 1
            }
        }
    ]
    doctor_data = list(collection.aggregate(pipeline))
    doctors = [doc["_id"] for doc in doctor_data]
    return doctors

@st.cache_data
def get_doctor_topic_trends(selected_doctor):
    pipeline = [
        {
            "$match": {
                "Doctor": selected_doctor,
                "Question Date": {"$type": "string"}
            }
        },
        {
            "$addFields": {
                "Question Date": {
                    "$dateFromString": {
                        "dateString": "$Question Date",
                        "format": "%Y-%m-%d"
                    }
                },
                "Year": {
                    "$year": {
                        "$dateFromString": {
                            "dateString": "$Question Date",
                            "format": "%Y-%m-%d"
                        }
                    }
                }
            }
        },
        {
            "$group": {
                "_id": {
                    "Year": "$Year",
                    "Topic": "$Topic"
                },
                "count": {"$sum": 1}
            }
        },
        {
            "$sort": {"_id.Year": 1}
        },
        {
            "$group": {
                "_id": "$_id.Year",
                "topics": {
                    "$push": {
                        "topic": "$_id.Topic",
                        "count": "$count"
                    }
                }
            }
        },
        {
            "$sort": {"_id": 1}
        }
    ]

    result = list(collection.aggregate(pipeline))
    data = []
    for record in result:
        date_record = {"Year": record["_id"]}
        for topic in record["topics"]:
            date_record[topic["topic"]] = topic["count"]
        data.append(date_record)
    
    df_doctor_topic_trends = pd.DataFrame(data).fillna(0)
    return df_doctor_topic_trends



@st.cache_data
def load_topic_data():
    pipeline = [
        {
            "$group": {
                "_id": "$Topic",
                "count": {"$sum": 1}
            }
        },
        {
            "$sort": {"count": -1}
        }
    ]
    topic_data = list(collection.aggregate(pipeline))
    df_topics = pd.DataFrame(topic_data)
    df_topics = df_topics.rename(columns={'_id': 'Topic', 'count': 'Count'})
    return df_topics

@st.cache_data
def sentiment_analysis(selected_topic=None):
    sia = SentimentIntensityAnalyzer()
    pipeline = [
        {"$match": {"Question Date": {"$type": "string"}}},
        {"$project": {"Answer": 1, "Doctor": 1, "Specialization": 1, "Topic": 1, "Question Date": 1}}
    ]
    data = list(collection.aggregate(pipeline))
    
    sentiments = {'positive': 0, 'negative': 0, 'neutral': 0}
    doctor_sentiments = {}
    specialization_sentiments = {}

    for item in data:
        if selected_topic and item.get('Topic') != selected_topic:
            continue

        answer = item.get('Answer', '')
        doctor = item.get('Doctor', 'Unknown')
        specialization = item.get('Specialization', 'Unknown')

        answer_sentiment = sia.polarity_scores(answer)
        combined_sentiment = answer_sentiment['compound']

        if doctor not in doctor_sentiments:
            doctor_sentiments[doctor] = {'positive': 0, 'negative': 0, 'neutral': 0, 'total': 0}
        if specialization not in specialization_sentiments:
            specialization_sentiments[specialization] = {'positive': 0, 'negative': 0, 'neutral': 0, 'total': 0}
        
        doctor_sentiments[doctor]['total'] += 1
        specialization_sentiments[specialization]['total'] += 1
        
        if combined_sentiment >= 0.2:
            sentiments['positive'] += 1
            doctor_sentiments[doctor]['positive'] += 1
            specialization_sentiments[specialization]['positive'] += 1
        elif combined_sentiment <= -0.2:
            sentiments['negative'] += 1
            doctor_sentiments[doctor]['negative'] += 1
            specialization_sentiments[specialization]['negative'] += 1
        else:
            sentiments['neutral'] += 1
            doctor_sentiments[doctor]['neutral'] += 1
            specialization_sentiments[specialization]['neutral'] += 1

    return sentiments, doctor_sentiments, specialization_sentiments, data

@st.cache_data
def get_topic_trend_data():    
    # Pipeline per aggregare i dati per anno
    pipeline = [
        {
            "$match": {
                "Question Date": {"$type": "string"}
            }
        },
        {
            "$addFields": {
                "Question Date": {
                    "$dateFromString": {
                        "dateString": "$Question Date",
                        "format": "%Y-%m-%d"
                    }
                },
                "Year": {
                    "$year": {
                        "$dateFromString": {
                            "dateString": "$Question Date",
                            "format": "%Y-%m-%d"
                        }
                    }
                }
            }
        },
        {
            "$group": {
                "_id": {
                    "Year": "$Year",
                    "Topic": "$Topic"
                },
                "count": {"$sum": 1}
            }
        },
        {
            "$sort": {"_id.Year": 1}
        },
        {
            "$group": {
                "_id": "$_id.Year",
                "topics": {
                    "$push": {
                        "topic": "$_id.Topic",
                        "count": "$count"
                    }
                }
            }
        },
        {
            "$sort": {"_id": 1}
        }
    ]

    result = list(collection.aggregate(pipeline))
    data = []
    for record in result:
        date_record = {"Year": record["_id"]}
        for topic in record["topics"]:
            date_record[topic["topic"]] = topic["count"]
        data.append(date_record)
    
    df_topic_trends = pd.DataFrame(data).fillna(0)
    return df_topic_trends

# Function to generate a random color
def random_color_func(word, font_size, position, orientation, random_state=None, **kwargs):
    return f"hsl({random.randint(0, 255)}, 100%, 50%)"

@st.cache_data
def load_geocoded_data():
    # Load all data from MongoDB
    data = list(collection.find({}, {"_id": 0, "Location": 1, "Doctor": 1, "Specialization": 1}))
    return pd.DataFrame(data)

@st.cache_data
def get_location_coordinates(location):
    try:
        if pd.isna(location):
            return (None, None)
        result = geocoder.geocode(location)
        if result and len(result) > 0:
            return (result[0]['geometry']['lat'], result[0]['geometry']['lng'])
        else:
            return (None, None)
    except Exception as e:
        st.error(f"Error: {e}")
        return (None, None)

@st.cache_data
def get_all_coordinates(locations):
    coordinates = {}
    for location in locations:
        if pd.notna(location):
            coordinates[location] = get_location_coordinates(location)
    return coordinates


@st.cache_data
def get_topic_specialization_data():
    # Pipeline to aggregate data and limit to top 20 topics and specializations
    pipeline = [
        {
            "$group": {
                "_id": "$Topic",
                "count": {"$sum": 1}
            }
        },
        {
            "$sort": {"count": -1}
        },
        {
            "$limit": 20
        },
        {
            "$lookup": {
                "from": "Medici55",
                "localField": "_id",
                "foreignField": "Topic",
                "as": "topic_docs"
            }
        },
        {
            "$unwind": "$topic_docs"
        },
        {
            "$group": {
                "_id": {
                    "Topic": "$_id",
                    "Specialization": "$topic_docs.Specialization"
                },
                "count": {"$sum": 1}
            }
        },
        {
            "$sort": {"count": -1}
        },
        {
            "$limit": 20
        },
        {
            "$project": {
                "_id": 0,
                "Topic": "$_id.Topic",
                "Specialization": "$_id.Specialization",
                "Count": "$count"
            }
        }
    ]

    result = list(collection.aggregate(pipeline))
    df_topic_specialization = pd.DataFrame(result)
    return df_topic_specialization

@st.cache_data 
def load_data(min_date, max_date):
    min_date = datetime.datetime.combine(min_date, datetime.datetime.min.time())
    max_date = datetime.datetime.combine(max_date, datetime.datetime.max.time())

    pipeline = [
        {
            "$match": {
                "Question Date": {"$type": "string"}
            }
        },
        {
            "$addFields": {
                "Question Date": {
                    "$dateFromString": {
                        "dateString": "$Question Date",
                        "format": "%Y-%m-%d"
                    }
                }
            }
        },
        {
            "$match": {
                "Question Date": {
                    "$gte": min_date,
                    "$lte": max_date
                }
            }
        },
        {
            "$group": {
                "_id": "$Question Date",
                "Number of Questions": {"$sum": 1}
            }
        },
        {
            "$sort": {"_id": 1}
        }
    ]

    data = list(collection.aggregate(pipeline))
    df = pd.DataFrame(data)
    df = df.rename(columns={'_id': 'Question Date'})
    return df

@st.cache_data
def get_data():
    pipeline = [
        {
            "$group": {
                "_id": "$Specialization",
                "count": {"$sum": 1}
            }
        },
        {
            "$sort": {"count": -1}
        },
        {
            "$limit": 20
        }
    ]
    
    top_20_specializations = list(collection.aggregate(pipeline))
    df_specializations = pd.DataFrame(top_20_specializations)
    
    if not df_specializations.empty:
        df_specializations.rename(columns={"_id": "Specialization", "count": "Number of Questions Answered"}, inplace=True)

    return df_specializations

@st.cache_data
def get_data_by_location(location):
    pipeline = [
        {
            "$match": {
                "Location": location
            }
        },
        {
            "$group": {
                "_id": {
                    "Specialization": "$Specialization",
                    "Doctor": "$Doctor"
                },
                "count": { "$sum": 1 }
            }
        },
        {
            "$project": {
                "_id": 0,
                "Specialization": "$_id.Specialization",
                "Doctor": "$_id.Doctor",
                "Count": "$count"
            }
        },
        {
            "$sort": {
                "Specialization": 1
            }
        }
    ]

    result = list(collection.aggregate(pipeline))
    df_location = pd.DataFrame(result)
    return df_location

@st.cache_data
def get_total_questions_by_url_prefix(url_prefix):
    pipeline = [
        {
            "$match": {
                "URL": {"$regex": f"^{url_prefix}"}
            }
        },
        {
            "$group": {
                "_id": None,
                "Total Questions": {"$sum": 1}
            }
        }
    ]

    result = list(collection.aggregate(pipeline))
    total_questions = result[0]['Total Questions'] if result else 0
    return total_questions

@st.cache_data
def load_response_time_data():
    pipeline = [ 
        {
            "$match": {
                "Question Date": {"$type": "string"},
                "Answer Date": {"$type": "string"}
            }
        },
        {
            "$addFields": {
                "Question Date": {
                    "$dateFromString": {
                        "dateString": "$Question Date",
                        "format": "%Y-%m-%d"
                    }
                },
                "Answer Date": {
                    "$dateFromString": {
                        "dateString": "$Answer Date",
                        "format": "%Y-%m-%d"
                    }
                }
            }
        },
        {
            "$project": {
                "Question Date": 1,
                "Answer Date": 1,
                "Response Time (Days)": {
                    "$dateDiff": {
                        "startDate": "$Question Date",
                        "endDate": "$Answer Date",
                        "unit": "day"
                    }
                }
            }
        }
    ]

    data = list(collection.aggregate(pipeline))
    df_response_time = pd.DataFrame(data)
    return df_response_time

# Set up the Streamlit app with page navigation
st.sidebar.title("Navigation")
main_page = st.sidebar.radio("Go to", ["Data Analysis", "Q&A Medical"])



if main_page == "Data Analysis":
    st.title("Data Analysis")

    sub_page = st.sidebar.radio("Select Subpage", ["Generale","Analytics temporali", "Analytics dei dati relativi ai medici", "Sentiment analysis"])


    if sub_page == "Generale":
        st.markdown("# Generale")
        
        st.write("\n")

        st.markdown("## 🔎 Numero di domande per sito")
        url_prefix = st.text_input("Enter URL prefix", "https://www.dica33.it")
        total_questions = get_total_questions_by_url_prefix(url_prefix)
        st.write(f"##### Numero totale di domande con l'url corrispondente")  
        st.write(f"##  {url_prefix}: {total_questions}")
        st.markdown("---")
        st.markdown("---")
        st.markdown("## 📑 Word Cloud of Topics")
        st.write(f"##### Topic più presenti nelle domande") 
        df_topics = load_topic_data()
        # Ensure the data is loaded successfully
        if not df_topics.empty:
            # Convert the topic data to a dictionary for the word cloud
            topic_dict = pd.Series(df_topics.Count.values, index=df_topics.Topic).to_dict()

            # Replace specific words in the dictionary
            if 'Sessualita' in topic_dict:
                topic_dict['Sessualità'] = topic_dict.pop('Sessualita')

            # Generate the word cloud
            wordcloud = WordCloud(
                width=800, 
                height=400, 
                background_color='white',
                color_func=random_color_func
            ).generate_from_frequencies(topic_dict)

            # Display the word cloud
            plt.figure(figsize=(15, 8))
            plt.imshow(wordcloud, interpolation='bilinear')
            plt.axis('off')
            plt.title('Word Cloud of Topics')
            st.pyplot(plt)
        else:
            st.write("No data found in the collection.")

    elif sub_page == "Analytics temporali":

        st.markdown("# Analisi temporale")
        
        st.write("\n")
        
        st.write("## 🔢Numero di domande nel tempo.")

        initial_data = load_data(datetime.datetime.min, datetime.datetime.max)
        st.write("\n")

        st.write("##### Selezione del range temporale")
        
        min_date = initial_data['Question Date'].min()
        max_date = initial_data['Question Date'].max()
        start_date, end_date = st.date_input(
            "",
            value=[min_date, max_date],
            min_value=min_date,
            max_value=max_date
        )

        df = load_data(start_date, end_date)

        fig = px.line(df, x='Question Date', y='Number of Questions', title='Numero di domande nel tempo')
        st.plotly_chart(fig)

        st.markdown("---")
        st.markdown("---")
        ############################
        df_response_time = load_response_time_data()

        # Downsample the data if it's too large
        if len(df_response_time) > 1000:
            df_response_time = df_response_time.sample(n=1000, random_state=42)

        if not df_response_time.empty:
            st.write("## ⏱️Distribuzione del response time (in Giorni)")
            fig_violin = px.violin(df_response_time, y="Response Time (Days)", box=True, points="all",
                                title=" Grafico a violino del Response Times")
            st.plotly_chart(fig_violin)

            st.markdown("---")
            st.markdown("---")

            st.write("## 🎲Grafico di ripartizione empirica del response Times")
            fig_ecdf = px.ecdf(df_response_time, x="Response Time (Days)", 
                            title="ECDF Plot of Response Times")
            st.plotly_chart(fig_ecdf)
        else:
            st.write("No response time data found.")
            
        st.markdown("---")
        st.markdown("---")


        st.write("## 📈Andamento dei topic nel tempo")

        df_topic_trends = get_topic_trend_data()

        # Riformatta il DataFrame per Plotly
        df_melted = df_topic_trends.melt(id_vars=["Year"], var_name="Topic", value_name="Count")

        # Ottieni la lista dei topic
        available_topics = df_melted["Topic"].unique()

        # Aggiungi una casella di controllo per selezionare i topic
        selected_topics = st.multiselect("Seleziona i topic", available_topics, default=available_topics)

        # Filtra il DataFrame per i topic selezionati
        filtered_df = df_melted[df_melted["Topic"].isin(selected_topics)]

        # Verifica se ci sono dati disponibili
        if not filtered_df.empty:
            # Crea un grafico ad area
            fig = px.area(filtered_df, x="Year", y="Count", color="Topic",
                    title="Andamento dei Topic nel Tempo",
                    labels={"Count": "Number of Questions", "Year": "Year", "Topic": "Topic"},
                    height=600)

            fig.update_layout(xaxis={'categoryorder':'total descending'},
                        xaxis_tickangle=-45)
        
            st.plotly_chart(fig)
        else:
            st.write("No data found for selected topic(s) over time.")

                
        st.write('## 📑Risposte dei dottori per topic nel tempo')

        # Load doctors and create a selectbox for doctor names
        doctors = load_doctors()
        selected_doctor = st.selectbox('Select a Doctor', doctors)

        # Fetch the topic trend data for the selected doctor
        if selected_doctor:
            df_trends = get_doctor_topic_trends(selected_doctor)
        if not df_trends.empty:
            fig = px.line(df_trends, x='Year', y=df_trends.columns[1:], title=f'Topic Trends Over Time for {selected_doctor}')
            st.plotly_chart(fig)
        else:
            st.write(f'No data available for {selected_doctor}')
    
    elif sub_page == "Analytics dei dati relativi ai medici":

        st.markdown("# Analytics dei dati relativi ai medici")
        
        st.write("\n")
        

        st.markdown("## 🔎 Top 20 specializzazioni")

        df_specializations = get_data()

        if not df_specializations.empty:
            
            plt.figure(figsize=(10, 6))
            plt.bar(df_specializations['Specialization'].astype(str), df_specializations['Number of Questions Answered'])
            plt.xlabel('Specialization')
            plt.ylabel('Number of Questions Answered')
            plt.title('Top 20 Specializations')
            plt.xticks(rotation=90)
            st.pyplot(plt)

        else:
            st.write("No data found in the collection.")

        st.markdown("---")
        st.markdown("---")

        st.markdown("## 📍Specializzazione e numero di dottori in base alla Città")

        locations = collection.distinct("Location")
        selected_location = st.selectbox("Select Location", locations)
        df_location = get_data_by_location(selected_location)


        if not df_location.empty:
            
            st.write("Specializations and Doctor Counts in", selected_location)
            st.dataframe(df_location)

            fig = px.bar(df_location, x="Specialization", y="Count", 
                        title="Specializations and their Counts", text="Count",
                        color="Specialization", color_discrete_sequence=px.colors.qualitative.Set3,
                        hover_data=["Doctor"])

            fig.update_traces(textposition='outside')

            fig.update_layout(
                xaxis={'categoryorder':'total ascending'},
                width=1200,
                height=800,
                title={
                    'text': "Specializations and their Counts",
                    'y':0.9,
                    'x':0.5,
                    'xanchor': 'center',
                    'yanchor': 'top'
                },
                xaxis_title="Specialization",
                yaxis_title="Count",
                font=dict(
                    family="Courier New, monospace",
                    size=14,
                    color="RebeccaPurple"
                ),
                xaxis_tickangle=-45,
                margin=dict(
                    l=100,
                    r=20,
                    t=100,
                    b=200
                )
            )
            st.plotly_chart(fig)
        else:
            st.write("No data found for the selected location.")


           
        st.markdown("---")
        st.markdown("---")

        st.markdown("## 📈Specializzazione e numero di dottori in base alla Città")
        df_topic_specialization = get_topic_specialization_data()

        # Check if data is available
        if not df_topic_specialization.empty:
            # Create a grouped bar chart
            fig = px.bar(df_topic_specialization, x='Topic', y='Count', color='Specialization', barmode='group',
                    title="",
                    labels={"Count": "Number of Questions", "Topic": "Topic", "Specialization": "Specialization"},
                    height=600)

            fig.update_layout(xaxis={'categoryorder':'total descending'},
                        xaxis_tickangle=-45)
        
            st.plotly_chart(fig)
        else:
            st.write("No data found for Topic-Specialization interaction.")
                # OpenCage API key

        st.markdown("---")
        st.markdown("---")

        st.markdown("## 🌍Mappa geografica dei medici per località")       
        #opencage_key = '660c0d5595ed4819ab7739495a54f0a8'
        opencage_key ='d013c45a75a14834be61780a3e088a9d'
        geocoder = OpenCageGeocode(opencage_key)
        # Load the data
        data = load_geocoded_data()
        # Recupera i dati dal MongoDB

        # Drop rows with NaN locations
        data = data.dropna(subset=['Location'])

        # Group by Location and Doctor, and count unique doctors per location
        location_counts = data.groupby('Location')['Doctor'].nunique().reset_index()
        location_counts.columns = ['Location', 'Count']

        # Get unique locations
        locations = data['Location'].unique()

        # Get all coordinates
        coordinates = get_all_coordinates(locations)

        # Initialize the map centered around Italy
        m = folium.Map(location=[41.8719, 12.5674], zoom_start=6)

        # Add markers to the map
        for idx, row in location_counts.iterrows():
            lat, lon = coordinates[row['Location']]
            if lat and lon:
                folium.Marker(
                    location=[lat, lon],
                popup=f"{row['Location']}: {row['Count']} doctors",
                    tooltip=row['Location']
                ).add_to(m)

        # Display the map with folium
        folium_static(m)

        # City selection
        selected_city = st.selectbox("Select a city", locations)

        # Filter data based on the selected city
        city_data = data[data['Location'] == selected_city]

        # Display details of the doctors in the selected city
        if not city_data.empty:
            st.write(f"Doctors in {selected_city}")
            st.dataframe(city_data.drop_duplicates(subset=['Doctor'])[['Doctor', 'Specialization', 'Location']])
        else:
            st.write(f"No data available for {selected_city}")

        # Zoom in on the selected city in the map
        if selected_city:
            lat, lon = coordinates[selected_city]
            if lat and lon:
                city_map = folium.Map(location=[lat, lon], zoom_start=12)
                folium.Marker(
                    location=[lat, lon],
                    popup=f"{selected_city}: {len(city_data['Doctor'].unique())} doctors",
                    tooltip=selected_city
                ).add_to(city_map)
                folium_static(city_map)
            else:
                st.write("Coordinates not found for the selected city.")



    elif sub_page == "Sentiment analysis":
        st.markdown("# Sentiment analysis")
        
        st.write("\n")
        
        st.write("## 😊Sentiment analysis delle risposte in base al topic.")
        
        # Load topics from the database
        topics = collection.distinct("Topic")

        # Select a topic
        selected_topic = st.selectbox("Select Topic", ["All"] + topics)

        # Perform sentiment analysis
        sentiments, doctor_sentiments, specialization_sentiments, full_data = sentiment_analysis(
            selected_topic if selected_topic != "All" else None
        )

        # Visualize sentiment analysis results
        st.write("Sentiment Analysis Results")
        fig, ax = plt.subplots()
        wedges, texts, autotexts = ax.pie(
            sentiments.values(), labels=sentiments.keys(), autopct='%1.1f%%', startangle=90, 
            colors=['#99ff99', '#ff9999', '#ffcc99'], pctdistance=0.85, labeldistance=1.1, textprops={'fontsize': 10}
        )
        ax.axis('equal')
        ax.legend(wedges, sentiments.keys(), title="Sentiments", loc="center left", bbox_to_anchor=(1, 0, 0.5, 1))
        st.pyplot(fig)

        st.markdown("---")
        st.markdown("---")

        # Interactive filters
        st.write("## 😞Sentiment analysis delle risposte in base al medico.")

        # Filter by doctor
        doctors_options = [doctor for doctor in doctor_sentiments.keys() if doctor != 'Unknown' and not pd.isna(doctor) and doctor != 'NaN']
        selected_doctor = st.selectbox("Select a Doctor", options=[''] + doctors_options)

        if selected_doctor != '':
            doctor_data = doctor_sentiments[selected_doctor]
            st.write(f"Sentiment Analysis for Dr. {selected_doctor}")
            fig, ax = plt.subplots()
            wedges, texts, autotexts = ax.pie(
            [doctor_data['positive'], doctor_data['neutral'], doctor_data['negative']],
                labels=['Positive', 'Neutral', 'Negative'],
                autopct='%1.1f%%', startangle=90,
                colors=['#99ff99', '#ffcc99', '#ff9999'],
                pctdistance=0.85, labeldistance=1.1, textprops={'fontsize': 10}
            )
            ax.axis('equal')
            ax.legend(wedges, ['Positive', 'Neutral', 'Negative'], title="Sentiments", loc="center left", bbox_to_anchor=(1, 0, 0.5, 1))
            st.pyplot(fig)
        
elif main_page == "Q&A Medical":
    st.title("Q&A Medical 🩺")
    st.write("Benvenuto nel nostro sistema di domande e risposte in ambito medico. Inserisci la tua domanda e ricevi una risposta accurata e professionale dai nostri esperti.")
    # Load the embedding model
    embedding_model = SentenceTransformer("thenlper/gte-large")

    def get_embedding(text: str) -> list:
        if not text.strip():
            st.warning("Attempted to get embedding for empty text.")
            return []
        embedding = embedding_model.encode(text)
        return embedding.tolist()

    def vector_search(user_query, collection):
        """
        Perform a vector search in the MongoDB collection based on the user query.
        Args:
        user_query (str): The user's query string.
        collection (MongoCollection): The MongoDB collection to search.
        Returns:
        list: A list of matching documents.
        """
        query_embedding = get_embedding(user_query)
        if not query_embedding:
            return []
        
        pipeline = [
            {
                "$vectorSearch": {
                    "index": "vector_index",
                    "queryVector": query_embedding,
                    "path": "embedding",
                    "numCandidates": 150,
                    "limit": 4,
                }
            },
            {
                "$project": {
                    "_id": 0,
                    "Question": 1,
                    "Answer": 1,
                    "score": {"$meta": "vectorSearchScore"},
                }
            }
        ]
        results = collection.aggregate(pipeline)
        return list(results)

    def get_search_result(query, collection):
        search_results = vector_search(query, collection)
        if not search_results:
            return "No relevant results found."

        formatted_results = ""
        for result in search_results:
            answer = result.get('Answer', 'N/A')
            formatted_results += f"Answer: {answer}\n"

        return formatted_results

    

    fireworks.client.api_key = "GIrjoNtlLb2xFAFhl5OIEUAaW9pusQec9WM53ELkMUopPoJV"
    #fireworks.client.api_key ="nt9JGss0fB2fUVkemEy9Ojn0E9yaqb5zJNdiGPZEOADJeIYA" altra api keys
    #altra api key in caso di utilizzi terminati per la prima
    mistral_llm = "mixtral-8x22b-instruct"

    def get_completion(prompt, model=None, max_tokens=50):
        fw_model_dir = "accounts/fireworks/models/"

        model = fw_model_dir + model

        completion = fireworks.client.Completion.create(
            model=model,
            prompt=prompt,
            max_tokens=max_tokens,
            temperature=0.3
        )

        return completion.choices[0].text

    def generate_answer(query):
        result = get_search_result(query, collection)
        prompt_template = prompt_template = f'''[INST]  <<SYS>>

You are a helpful, respectful and honest Doctor. Always answer as helpfully as possible using the context text provided. In your response don't include any phrase from {result}. Rielaborate new one. Use only the knowledge in context to answer
Keep the answer short and concise. Don't answer many times. Answer only one time

Use only the knowledge in context to answer.

Answer only to medical question. If the question is not medical type, say: mi dispiace, non posso risponderla in questo ambito

If you don't have enought knowledge to answer the question, say : Non ho abbastanza informazioni per risponderti, ti consiglio di andare da uno specialista per verificare la sua condizione.

Start with "gentile paziente"

End with "Cordiali saluti", "Distinti saluti", "Saluti" or "Con affetto e stima"

You must answer in Italian. Don't use English. Use ONLY ITALIAN. Respond just one time.

You must use only the Italian.

to answer, use max 300 word


You must not include the {result} in the answer. You must use result to generate a new answer from 0. Don't make a list while answering.
In the answer, don't use any phrase from {result}.

You must not use {result} in the answer. Elaborate from 0 a new one. Just use this knowledge. You must use only this to answer. Don't use other knowledge
<<SYS>>




"""CONTEXT:/n/n {result}/n



EXAMPLE:

Follow this structure of answers. Use those only for the structure. Don't use any context. Don't include inside the answer any of those
Esempio 1:
Gentile paziente,
Il dolore al petto può avere molte cause, alcune delle quali sono gravi.
Potrebbe trattarsi di un problema cardiaco, come l'angina o un infarto, oppure di una condizione meno grave, come il reflusso gastroesofageo o uno spasmo muscolare.
È importante che tu venga visitato il prima possibile per escludere cause gravi. Ti consiglio di recarti al pronto soccorso o di fissare un appuntamento con il tuo medico di famiglia.
Saluti!

Esempio 2:
Gentile paziente,
I mal di testa persistenti possono avere molte cause, tra cui stress, tensione muscolare, problemi alla vista, sinusite, emicrania o, più raramente, patologie più gravi come tumori cerebrali.
È importante identificare il tipo di mal di testa e i fattori scatenanti.
Ti consiglio di tenere un diario dei sintomi e di consultare un medico per una valutazione approfondita e per determinare la causa esatta del tuo mal di testa.
Buona giornata!

Esempio 3:
Gentile paziente,
Una tosse che persiste per più di tre settimane è considerata cronica e può avere diverse cause, come un'infezione respiratoria prolungata, asma, bronchite cronica, reflusso gastroesofageo o, in rari casi, tumori polmonari.
È importante eseguire una valutazione completa, che potrebbe includere un esame fisico, radiografie del torace e, se necessario, ulteriori test.
Ti consiglio di fissare un appuntamento con il tuo medico per discutere i tuoi sintomi e pianificare gli esami necessari. Cordiali saluti.

Esempio 4:
Gentile paziente,
Un'eruzione cutanea pruriginosa può avere molte cause, tra cui reazioni allergiche, dermatite da contatto, infezioni, malattie autoimmuni o effetti collaterali di farmaci.
È importante valutare l'aspetto dell'eruzione, la sua distribuzione e altri sintomi associati.
Ti consiglio di evitare prodotti che potrebbero irritare ulteriormente la pelle e di consultare un dermatologo per una diagnosi accurata e un trattamento appropriato.
Distinti saluti.

Esempio 5:
Gentile paziente,
Il gonfiore alle gambe può essere causato da molte condizioni, tra cui insufficienza venosa, ritenzione di liquidi, insufficienza cardiaca, problemi renali o epatici, e infezioni.
Il fatto che il gonfiore peggiori la sera potrebbe suggerire un problema di circolazione.
Ti consiglio di mantenere le gambe sollevate quando possibile e di fissare un appuntamento con il tuo medico per una valutazione completa e per determinare la causa esatta del gonfiore.
Cordialmente

Esempio 6:
Gentile paziente,
I sintomi del diabete possono variare a seconda del tipo di diabete e del livello di glicemia nel sangue.
Con affetto e stima


Question: {query} [/INST]
Risposta: (keep this simple, don't repeat in any case word or phrase)
'''
        response = get_completion(prompt_template, model=mistral_llm, max_tokens=800)
        return response

    st.write("Inserisci la tua domanda medica:")
    user_query = st.text_area("Query")
    
    if st.button("Genera Risposta"):
        if user_query.strip():
            with st.spinner("Generando risposta..."):
                answer = generate_answer(user_query)
                st.write("Risposta:")
                st.write(answer)
        else:
            st.warning("Per favore, inserisci una domanda valida.")

